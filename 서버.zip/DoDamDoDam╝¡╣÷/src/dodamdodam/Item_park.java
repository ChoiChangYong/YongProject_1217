/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

/**
 *
 * @author ChangYong
 */
public class Item_park {
    private String parkFacility1;
    private String parkFacility2;
    private String parkType;
    private String phone2;
    private String parkFacility3;
    private String longitude;
    private String name;
    private String parkFacility4;
    private String parkExtent;
    private String address;
    private String latitude;
    private String suportName;
    private String addr;
    private String parkFacility5;
    private String manageNum;
    private String dateMade;
    private String _id;
    private String phone;
    private String date;

    public String getParkFacility1() {
        return parkFacility1;
    }

    public void setParkFacility1(String parkFacility1) {
        this.parkFacility1 = parkFacility1;
    }

    public String getParkFacility2() {
        return parkFacility2;
    }

    public void setParkFacility2(String parkFacility2) {
        this.parkFacility2 = parkFacility2;
    }

    public String getParkType() {
        return parkType;
    }

    public void setParkType(String parkType) {
        this.parkType = parkType;
    }

    public String getPhone2() {
        return phone2;
    }

    public void setPhone2(String phone2) {
        this.phone2 = phone2;
    }

    public String getParkFacility3() {
        return parkFacility3;
    }

    public void setParkFacility3(String parkFacility3) {
        this.parkFacility3 = parkFacility3;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParkFacility4() {
        return parkFacility4;
    }

    public void setParkFacility4(String parkFacility4) {
        this.parkFacility4 = parkFacility4;
    }

    public String getParkExtent() {
        return parkExtent;
    }

    public void setParkExtent(String parkExtent) {
        this.parkExtent = parkExtent;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getSuportName() {
        return suportName;
    }

    public void setSuportName(String suportName) {
        this.suportName = suportName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getParkFacility5() {
        return parkFacility5;
    }

    public void setParkFacility5(String parkFacility5) {
        this.parkFacility5 = parkFacility5;
    }

    public String getManageNum() {
        return manageNum;
    }

    public void setManageNum(String manageNum) {
        this.manageNum = manageNum;
    }

    public String getDateMade() {
        return dateMade;
    }

    public void setDateMade(String dateMade) {
        this.dateMade = dateMade;
    }

    public String getId() {
        return _id;
    }

    public void setId(String _id) {
        this._id = _id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    
}
