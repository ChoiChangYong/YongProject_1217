/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ChangYong
 */
public class DBConnect_parsing {
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    public DBConnect_parsing()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/childhouse", "root", "111111");
            st = con.createStatement();
        } 
        catch (Exception e) 
        {
            System.out.println("데이터베이스 연결 오류 : " + e.getMessage());
        }
    }
    
    public boolean isAdmin(String adminID, String adminPassword)
    {
        try
        {
            String SQL = "SELECT * FROM ADMIN WHERE adminID = '" + adminID + "' and adminPassword = '" + adminPassword + "'";
            rs = st.executeQuery(SQL);
            if(rs.next())
            {
                return true;
            }
        }
        catch(Exception e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }
    public boolean DBInsert_hospital(Item_hospital pItem)
    {
        try
        {
            rs = CheckUniqueDB(pItem.getXPos());
            if (rs.next() == false) {
                String Col = "sidoCdNm, sgguCdNm, yadmNm, clCdNm, drTotCnt, XPos, YPos, addr, telno";
                String Table = "hospital";
                String Value = "'" + pItem.getSidoCdNm() + "', " + "'" + pItem.getSgguCdNm() + "', " + "'" + pItem.getYadmNm() + "', "
                        + "'" + pItem.getClCdNm() + "', " + "'" + pItem.getDrTotCnt() + "', " + "'" + pItem.getXPos() + "', "
                        + "'" + pItem.getYPos() + "', " + "'" + pItem.getAddr() + "', " + "'" + pItem.getTelno() + "'";
                String SQL = "INSERT INTO `" + Table + "` (" + Col + ") VALUES(" + Value + ")";
                System.out.println(SQL);
                st.executeUpdate(SQL);
                return true;
            } 
            else {
                return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }
    public boolean DBInsert_childhouse(Item_childhouse pItem)
    {
        try
        {
            rs = CheckUniqueDB(pItem.getId_());
            if (rs.next() == false) {
                String Col = "city, fax, name, type, bigcity, longitude, date, car, phone, homepage, cctvNum, addrRoad, member, playground, teacher, _id, latitude, room";
                String Table = "child_house";
                String Value = "'" + pItem.getCity2name() + "', " + "'" + pItem.getPaxnum() + "', " + "\"" + pItem.getName() + "\", "
                        + "'" + pItem.getType() + "', " + "'" + pItem.getCityname() + "', " + "'" + pItem.getXPos() + "', "
                        + "'" + pItem.getDate() + "', " + "'" + pItem.getHouse_car_flag() + "', " + "'" + pItem.getTelno() + "', "
                        + "'" + pItem.getHomepage() + "', " + "'" + pItem.getCctv() + "', " + "'" + pItem.getAddr() + "', "
                        + "'" + pItem.getPerson_num() + "', " + "'" + pItem.getPlayground_num() + "', " + "'" + pItem.getTeacher_num() + "', "
                        + "'" + pItem.getId_() + "', " + "'" + pItem.getYPos() + "', " + "'" + pItem.getRoom() + "'";
                String SQL = "INSERT INTO `" + Table + "` (" + Col + ") VALUES(" + Value + ")";
                System.out.println(SQL);
                st.executeUpdate(SQL);
                return true;
            }
            else
                return false;
        }
        catch(Exception e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }
    
    public boolean DBInsert_childPRTC(Item_childPRTC pItem)
    {
        try
        {
            rs = CheckUniqueDB(pItem.getId());
            if (rs.next() == false) {
                String Col = "type , date , longitude , name , addrRoad , cctvFlag , latitude , suportName , addr , police , _id , cctvNum , roadWidth";
                String Table = "childprtc";
                String Value = "'" + pItem.getType() + "', " + "'" + pItem.getDate() + "', " + "\"" + pItem.getLongitude() + "\", "
                        + "'" + pItem.getName() + "', " + "'" + pItem.getAddrRoad() + "', " + "'" + pItem.getCctvFlag() + "', "
                        + "'" + pItem.getLatitude() + "', " + "'" + pItem.getSuportName() + "', " + "'" + pItem.getAddr() + "', "
                        + "'" + pItem.getPolice() + "', " + "'" + pItem.getId() + "', " + "'" + pItem.getCctvNum() + "', "
                        + "'" + pItem.getRoadWidth() + "'";
                String SQL = "INSERT INTO `" + Table + "` (" + Col + ") VALUES(" + Value + ")";
                System.out.println(SQL);
                st.executeUpdate(SQL);
                return true;
            }
            else
                return false;
        }
        catch(Exception e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }
    
    public boolean DBInsert_park(Item_park pItem)
    {
        try
        {
            rs = CheckUniqueDB(pItem.getId());
            if (rs.next() == false) {
                String Col = "parkFacility1, parkFacility2, parkType, phone2, parkFacility3, longitude, name, parkFacility4, parkExtent, address, latitude, suportName, addr, parkFacility5, manageNum, dateMade, _id, phone, date";
                String Table = "park";
                String Value = "'" + pItem.getParkFacility1() + "', " + "'" + pItem.getParkFacility2() + "', " + "\"" + pItem.getParkType() + "\", "
                        + "'" + pItem.getPhone2() + "', " + "'" + pItem.getParkFacility3() + "', " + "'" + pItem.getLongitude() + "', "
                        + "'" + pItem.getName() + "', " + "'" + pItem.getParkFacility4() + "', " + "'" + pItem.getParkExtent() + "', "
                        + "'" + pItem.getAddress() + "', " + "'" + pItem.getLatitude() + "', " + "'" + pItem.getSuportName() + "', "
                        + "'" + pItem.getAddr() + "', " + "'" + pItem.getParkFacility5() + "', " + "'" + pItem.getManageNum() + "', "
                        + "'" + pItem.getDateMade() + "', " + "'" + pItem.getId() + "', " + "'" + pItem.getPhone() + "', " + "'" + pItem.getDate() +"'";
                String SQL = "INSERT INTO `" + Table + "` (" + Col + ") VALUES(" + Value + ")";
                System.out.println(SQL);
                st.executeUpdate(SQL);
                return true;
            }
            else
                return false;
        }
        catch(Exception e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }
    
    public boolean DBInsert_frequentzone(Item_frequentzone pItem)
    {
        try
        {
                String Col = "id, grp_id, name, occrrnc_co, dthinj_co, death_co, XPos, YPos";
                String Table = "frequentzonechild";
                String Value = "'" + pItem.getId()+ "', " + "'" + pItem.getGrp_id()+ "', " + "\"" + pItem.getName()+ "\", "
                        + "'" + pItem.getOccrrnc_co()+ "', " + "'" + pItem.getDthinj_co()+ "', " + "'" + pItem.getDeath_co()+ "', "
                        + "'" + pItem.getXPos()+ "', " + "'" + pItem.getYPos()+ "'";
                String SQL = "INSERT INTO `" + Table + "` (" + Col + ") VALUES(" + Value + ")";
                System.out.println(SQL);
                st.executeUpdate(SQL);
                return true;
        }
        catch(SQLException e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }
    public boolean DBInsert_schoolzone(Item_schoolzone pItem)
    {
        try
        {
                String Col = "id, grp_id, name, occrrnc_co, dthinj_co, death_co, XPos, YPos";
                String Table = "schoolzonechild";
                String Value = "'" + pItem.getId()+ "', " + "'" + pItem.getGrp_id()+ "', " + "\"" + pItem.getName()+ "\", "
                        + "'" + pItem.getOccrrnc_co()+ "', " + "'" + pItem.getDthinj_co()+ "', " + "'" + pItem.getDeath_co()+ "', "
                        + "'" + pItem.getXPos()+ "', " + "'" + pItem.getYPos()+ "'";
                String SQL = "INSERT INTO `" + Table + "` (" + Col + ") VALUES(" + Value + ")";
                System.out.println(SQL);
                st.executeUpdate(SQL);
                return true;
        }
        catch(SQLException e)
        {
            System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
        }
        return false;
    }

    public ResultSet CheckUniqueDB(String id)
    {
        ResultSet result = null;
        String SQL = "SELECT * FROM park WHERE XPos="+ id;
        try
        {
            result = st.executeQuery(SQL);
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return result;
    }
    
    public void a()
    {
        ResultSet result = null;
        String SQL = "SELECT * FROM child_house WHERE _id="+ "3.0";
        try
        {
            result = st.executeQuery(SQL);
            System.out.println("result : " + result.next());
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public void b()
    {
        ResultSet result = null;
        String SQL = "select * from hospital where sidoCdNm='서울'&&sgguCdNm='동대문구'";
        try
        {
            ResultSet rs = st.executeQuery(SQL);
            //System.out.println("result : " + result.next());
            while (rs.next()) {
                String lastName = rs.getString("yadmNm");
                System.out.println(lastName + "\n");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}