/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

/**
 *
 * @author ChangYong
 */
public class Item_childhouse {
    private String city2name;
    private String paxnum;
    private String name;
    private String type;
    private String cityname;
    private String YPos;
    private String date;
    private String house_car_flag;
    private String telno;
    private String homepage;
    private String cctv;
    private String addr;
    private String person_num;
    private String playground_num;
    private String teacher_num;
    private String id_;
    private String XPos;
    private String room;    

    public String getCity2name() {
        return city2name;
    }

    public void setCity2name(String city2name) {
        this.city2name = city2name;
    }

    public String getPaxnum() {
        return paxnum;
    }

    public void setPaxnum(String paxnum) {
        this.paxnum = paxnum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getXPos() {
        return XPos;
    }

    public void setXPos(String XPos) {
        this.XPos = XPos;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHouse_car_flag() {
        return house_car_flag;
    }

    public void setHouse_car_flag(String house_car_flag) {
        this.house_car_flag = house_car_flag;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    public String getCctv() {
        return cctv;
    }

    public void setCctv(String cctv) {
        this.cctv = cctv;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getPerson_num() {
        return person_num;
    }

    public void setPerson_num(String person_num) {
        this.person_num = person_num;
    }

    public String getPlayground_num() {
        return playground_num;
    }

    public void setPlayground_num(String playground_num) {
        this.playground_num = playground_num;
    }

    public String getTeacher_num() {
        return teacher_num;
    }

    public void setTeacher_num(String teacher_num) {
        this.teacher_num = teacher_num;
    }

    public String getId_() {
        return id_;
    }

    public void setId_(String id_) {
        this.id_ = id_;
    }

    public String getYPos() {
        return YPos;
    }

    public void setYPos(String YPos) {
        this.YPos = YPos;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }
    
}
