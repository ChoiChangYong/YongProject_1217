/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

/**
 *
 * @author ChangYong
 */
public class Item_frequentzone {
    private String id;
    private String grp_id;
    private String name;
    private String occrrnc_co;
    private String dthinj_co;
    private String death_co;
    private String XPos;
    private String YPos;

    public Item_frequentzone() {
        this.id = "";
        this.grp_id = "";
        this.name = "";
        this.occrrnc_co = "";
        this.dthinj_co = "";
        this.death_co = "";
        this.XPos = "";
        this.YPos = "";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGrp_id() {
        return grp_id;
    }

    public void setGrp_id(String grp_id) {
        this.grp_id = grp_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOccrrnc_co() {
        return occrrnc_co;
    }

    public void setOccrrnc_co(String occrrnc_co) {
        this.occrrnc_co = occrrnc_co;
    }

    public String getDthinj_co() {
        return dthinj_co;
    }

    public void setDthinj_co(String dthinj_co) {
        this.dthinj_co = dthinj_co;
    }

    public String getDeath_co() {
        return death_co;
    }

    public void setDeath_co(String death_co) {
        this.death_co = death_co;
    }

    public String getXPos() {
        return XPos;
    }

    public void setXPos(String XPos) {
        this.XPos = XPos;
    }

    public String getYPos() {
        return YPos;
    }

    public void setYPos(String YPos) {
        this.YPos = YPos;
    }
    
}
