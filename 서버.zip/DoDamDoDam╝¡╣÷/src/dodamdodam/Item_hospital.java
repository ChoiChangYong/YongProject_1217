/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

/**
 *
 * @author user
 */
public class Item_hospital {
    private String addr;
    private String clCdNm;
    private String drTotCnt;
    private String sgguCdNm;
    private String sidoCdNm;
    private String telno;
    private String XPos;
    private String YPos;
    private String yadmNm;


    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getClCdNm() {
        return clCdNm;
    }

    public void setClCdNm(String clCdNm) {
        this.clCdNm = clCdNm;
    }

    public String getDrTotCnt() {
        return drTotCnt;
    }

    public void setDrTotCnt(String drTotCnt) {
        this.drTotCnt = drTotCnt;
    }

    public String getSgguCdNm() {
        return sgguCdNm;
    }

    public void setSgguCdNm(String sgguCdNm) {
        this.sgguCdNm = sgguCdNm;
    }

    public String getSidoCdNm() {
        return sidoCdNm;
    }

    public void setSidoCdNm(String sidoCdNm) {
        this.sidoCdNm = sidoCdNm;
    }

    public String getTelno() {
        return telno;
    }

    public void setTelno(String telno) {
        this.telno = telno;
    }

    public String getXPos() {
        return XPos;
    }

    public void setXPos(String XPos) {
        this.XPos = XPos;
    }

    public String getYPos() {
        return YPos;
    }

    public void setYPos(String YPos) {
        this.YPos = YPos;
    }

    public String getYadmNm() {
        return yadmNm;
    }

    public void setYadmNm(String yadmNm) {
        this.yadmNm = yadmNm;
    }
    
    Item_hospital()
    {
        addr = "";
        clCdNm = "";
        drTotCnt = "";
        sgguCdNm = "";
        sidoCdNm = "";
        telno = "";
        XPos = "";
        YPos = "";
        yadmNm = "";
    }
}
