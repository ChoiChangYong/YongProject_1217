/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

/**
 *
 * @author ChangYong
 */
public class Item_childPRTC {
    private String type ;
    private String date ;
    private String longitude ;
    private String name ;
    private String addrRoad ;
    private String cctvFlag ;
    private String latitude ;
    private String suportName ;
    private String addr ;
    private String police ;
    private String _id ;
    private String cctvNum ;
    private String roadWidth;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddrRoad() {
        return addrRoad;
    }

    public void setAddrRoad(String addrRoad) {
        this.addrRoad = addrRoad;
    }

    public String getCctvFlag() {
        return cctvFlag;
    }

    public void setCctvFlag(String cctvFlag) {
        this.cctvFlag = cctvFlag;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getSuportName() {
        return suportName;
    }

    public void setSuportName(String suportName) {
        this.suportName = suportName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getPolice() {
        return police;
    }

    public void setPolice(String police) {
        this.police = police;
    }

    public String getId() {
        return _id;
    }

    public void setId(String _id) {
        this._id = _id;
    }

    public String getCctvNum() {
        return cctvNum;
    }

    public void setCctvNum(String cctvNum) {
        this.cctvNum = cctvNum;
    }

    public String getRoadWidth() {
        return roadWidth;
    }

    public void setRoadWidth(String roadWidth) {
        this.roadWidth = roadWidth;
    }
    
    
}
