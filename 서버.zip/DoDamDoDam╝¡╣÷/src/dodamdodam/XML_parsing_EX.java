/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author user
 */
public class XML_parsing_EX {

    static void Childhouse() throws ParserConfigurationException, SAXException, IOException {
        DBConnect_parsing connection = new DBConnect_parsing();
        Item_childhouse pItem = new Item_childhouse();

        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Document doc;
        String strServiceKey_ = "1K4xNbu%2FFeXw9unO7O8Buk%2BLKkHhNI%2F0uPzNY5NjUEdvQBFoqXOibJ2uz%2BYO3wZKJENXQXh7qi2Ligdjx5c0KA%3D%3D";

        String strUrl = "http://api.data.go.kr/openapi/child-house-std";
        String strServiceKey = "?serviceKey=" + strServiceKey_;
        String strPage = "&s_page=";
        int page = 1;
        for (page = 1;; page += 10) {
            String strA = strPage + page + "&type=xml";
            String strMyURL = strUrl + strServiceKey + strA;

            System.out.println(strMyURL);

            factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            doc = builder.parse(strMyURL);

            NodeList list = doc.getElementsByTagName("com.google.gson.internal.LinkedTreeMap");
            int j = 0;
            for (int i = 0; i < list.getLength(); i++) {
                for (Node node = list.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {
                    if (node.getNodeName().equals("entry")) {
                        for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
                            if (node2.getNodeName().equals("string")) {
                                if (j % 2 == 0) {
                                    j++;
                                    node2.getTextContent();
                                    continue;
                                }
                                if (j % 2 == 1) {
                                    if (j % 36 == 1) {
                                        pItem.setCity2name(node2.getTextContent());
                                    }
                                    if (j % 36 == 3) {
                                        pItem.setPaxnum(node2.getTextContent());
                                    }
                                    if (j % 36 == 5) {
                                        pItem.setName(node2.getTextContent());
                                    }
                                    if (j % 36 == 7) {
                                        pItem.setType(node2.getTextContent());
                                    }
                                    if (j % 36 == 9) {
                                        pItem.setCityname(node2.getTextContent());
                                    }
                                    if (j % 36 == 11) {
                                        pItem.setYPos(node2.getTextContent());
                                    }
                                    if (j % 36 == 13) {
                                        pItem.setDate(node2.getTextContent());
                                    }
                                    if (j % 36 == 15) {
                                        pItem.setHouse_car_flag(node2.getTextContent());
                                    }
                                    if (j % 36 == 17) {
                                        pItem.setTelno(node2.getTextContent());
                                    }
                                    if (j % 36 == 19) {
                                        pItem.setHomepage(node2.getTextContent());
                                    }
                                    if (j % 36 == 21) {
                                        pItem.setCctv(node2.getTextContent());
                                    }
                                    if (j % 36 == 23) {
                                        pItem.setAddr(node2.getTextContent());
                                    }
                                    if (j % 36 == 25) {
                                        pItem.setPerson_num(node2.getTextContent());
                                    }
                                    if (j % 36 == 27) {
                                        pItem.setPlayground_num(node2.getTextContent());
                                    }
                                    if (j % 36 == 29) {
                                        pItem.setTeacher_num(node2.getTextContent());
                                    }
                                    if (j % 36 == 33) {
                                        pItem.setXPos(node2.getTextContent());
                                    }
                                    if (j % 36 == 35) {
                                        pItem.setRoom(node2.getTextContent());
                                    }
                                    j++;
                                }
                            }
                            if (node2.getNodeName().equals("null")) {
                                if (j % 2 == 1) {
                                    System.out.println(node2.getTextContent());
                                    if (j % 36 == 1) {
                                        pItem.setCity2name(node2.getTextContent());
                                    }
                                    if (j % 36 == 3) {
                                        pItem.setPaxnum(node2.getTextContent());
                                    }
                                    if (j % 36 == 5) {
                                        pItem.setName(node2.getTextContent());
                                    }
                                    if (j % 36 == 7) {
                                        pItem.setType(node2.getTextContent());
                                    }
                                    if (j % 36 == 9) {
                                        pItem.setCityname(node2.getTextContent());
                                    }
                                    if (j % 36 == 11) {
                                        pItem.setYPos(node2.getTextContent());
                                    }
                                    if (j % 36 == 13) {
                                        pItem.setDate(node2.getTextContent());
                                    }
                                    if (j % 36 == 15) {
                                        pItem.setHouse_car_flag(node2.getTextContent());
                                    }
                                    if (j % 36 == 17) {
                                        pItem.setTelno(node2.getTextContent());
                                    }
                                    if (j % 36 == 19) {
                                        pItem.setHomepage(node2.getTextContent());
                                    }
                                    if (j % 36 == 21) {
                                        pItem.setCctv(node2.getTextContent());
                                    }
                                    if (j % 36 == 23) {
                                        pItem.setAddr(node2.getTextContent());
                                    }
                                    if (j % 36 == 25) {
                                        pItem.setPerson_num(node2.getTextContent());
                                    }
                                    if (j % 36 == 27) {
                                        pItem.setPlayground_num(node2.getTextContent());
                                    }
                                    if (j % 36 == 29) {
                                        pItem.setTeacher_num(node2.getTextContent());
                                    }
                                    if (j % 36 == 31) {
                                        pItem.setId_(node2.getTextContent());
                                    }
                                    if (j % 36 == 33) {
                                        pItem.setXPos(node2.getTextContent());
                                    }
                                    if (j % 36 == 35) {
                                        pItem.setRoom(node2.getTextContent());
                                    }
                                }
                                j++;
                            }
                            if (node2.getNodeName().equals("double")) {
                                if (j % 2 == 1) {
                                    if (j % 36 == 31) {
                                        pItem.setId_(node2.getTextContent());
                                    }
                                }
                                j++;
                            }
                        }
                    }
                }
                if (connection.DBInsert_childhouse(pItem) == false) {
                    break;
                }
            }
        }

    }

    static void ChildPRCT() throws ParserConfigurationException, SAXException, IOException {
        DBConnect_parsing connection = new DBConnect_parsing();

        Item_childPRTC pItem = new Item_childPRTC();

        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Document doc;
        String strServiceKey_ = "1K4xNbu%2FFeXw9unO7O8Buk%2BLKkHhNI%2F0uPzNY5NjUEdvQBFoqXOibJ2uz%2BYO3wZKJENXQXh7qi2Ligdjx5c0KA%3D%3D";

        String strUrl = "http://api.data.go.kr/openapi/child-prtc-zn-std";
        String strServiceKey = "?serviceKey=" + strServiceKey_;
        String strPage = "&s_page=";
        int page = 1;
        for (page = 1;; page += 10) {
            String strA = strPage + page + "&type=xml";
            String strMyURL = strUrl + strServiceKey + strA;

            System.out.println(strMyURL);

            factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            doc = builder.parse(strMyURL);

            NodeList list = doc.getElementsByTagName("com.google.gson.internal.LinkedTreeMap");
            int j = 0;
            for (int i = 0; i < list.getLength(); i++) {
                for (Node node = list.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {
                    if (node.getNodeName().equals("entry")) {
                        for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
                            if (node2.getNodeName().equals("string")) {
                                if (j % 2 == 0) {
                                    j++;
                                    node2.getTextContent();
                                    continue;
                                }
                                if (j % 2 == 1) {
                                    if (j % 26 == 1) {
                                        pItem.setType(node2.getTextContent());
                                    }
                                    if (j % 26 == 3) {
                                        pItem.setDate(node2.getTextContent());
                                    }
                                    if (j % 26 == 5) {
                                        pItem.setLongitude(node2.getTextContent());
                                    }
                                    if (j % 26 == 7) {
                                        pItem.setName(node2.getTextContent());
                                    }
                                    if (j % 26 == 9) {
                                        pItem.setAddrRoad(node2.getTextContent());
                                    }
                                    if (j % 26 == 11) {
                                        pItem.setCctvFlag(node2.getTextContent());
                                    }
                                    if (j % 26 == 13) {
                                        pItem.setLatitude(node2.getTextContent());
                                    }
                                    if (j % 26 == 15) {
                                        pItem.setSuportName(node2.getTextContent());
                                    }
                                    if (j % 26 == 17) {
                                        pItem.setAddr(node2.getTextContent());
                                    }
                                    if (j % 26 == 19) {
                                        pItem.setPolice(node2.getTextContent());
                                    }
                                    if (j % 26 == 23) {
                                        pItem.setCctvNum(node2.getTextContent());
                                    }
                                    if (j % 26 == 25) {
                                        pItem.setRoadWidth(node2.getTextContent());
                                    }
                                    j++;
                                }
                            }
                            if (node2.getNodeName().equals("null")) {
                                if (j % 2 == 1) {
                                    System.out.println(node2.getTextContent());
                                    if (j % 26 == 1) {
                                        pItem.setType(node2.getTextContent());
                                    }
                                    if (j % 26 == 3) {
                                        pItem.setDate(node2.getTextContent());
                                    }
                                    if (j % 26 == 5) {
                                        pItem.setLongitude(node2.getTextContent());
                                    }
                                    if (j % 26 == 7) {
                                        pItem.setName(node2.getTextContent());
                                    }
                                    if (j % 26 == 9) {
                                        pItem.setAddrRoad(node2.getTextContent());
                                    }
                                    if (j % 26 == 11) {
                                        pItem.setCctvFlag(node2.getTextContent());
                                    }
                                    if (j % 26 == 13) {
                                        pItem.setLatitude(node2.getTextContent());
                                    }
                                    if (j % 26 == 15) {
                                        pItem.setSuportName(node2.getTextContent());
                                    }
                                    if (j % 26 == 17) {
                                        pItem.setAddr(node2.getTextContent());
                                    }
                                    if (j % 26 == 19) {
                                        pItem.setPolice(node2.getTextContent());
                                    }
                                    if (j % 26 == 21) {
                                        pItem.setId(node2.getTextContent());
                                    }
                                    if (j % 26 == 23) {
                                        pItem.setCctvNum(node2.getTextContent());
                                    }
                                    if (j % 26 == 25) {
                                        pItem.setRoadWidth(node2.getTextContent());
                                    }
                                }
                                j++;
                            }
                            if (node2.getNodeName().equals("double")) {
                                if (j % 2 == 1) {
                                    if (j % 26 == 21) {
                                        pItem.setId(node2.getTextContent());
                                    }
                                }
                                j++;
                            }
                        }
                    }
                }
                if (connection.DBInsert_childPRTC(pItem) == false) {
                    break;
                }
            }
        }

    }

    static void Park() throws ParserConfigurationException, SAXException, IOException {
        DBConnect_parsing connection = new DBConnect_parsing();
        Item_park pItem = new Item_park();

        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Document doc;
        String strServiceKey_ = "1K4xNbu%2FFeXw9unO7O8Buk%2BLKkHhNI%2F0uPzNY5NjUEdvQBFoqXOibJ2uz%2BYO3wZKJENXQXh7qi2Ligdjx5c0KA%3D%3D";

        String strUrl = "http://api.data.go.kr/openapi/cty-park-info-std";
        String strServiceKey = "?serviceKey=" + strServiceKey_;
        String strPage = "&s_list=10&s_page=";
        int page = 1;
        for (page = 1;; page += 10) {
            String strA = strPage + page + "&type=xml";
            String strMyURL = strUrl + strServiceKey + strA;

            System.out.println(strMyURL);

            factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            doc = builder.parse(strMyURL);
            System.out.println("parsing start to "+page+"page");
            NodeList list = doc.getElementsByTagName("com.google.gson.internal.LinkedTreeMap");
            int j = 0;
            for (int i = 0; i < list.getLength(); i++) {
                for (Node node = list.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {
                    if (node.getNodeName().equals("entry")) {
                        for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
                            if (node2.getNodeName().equals("string")) {
                                if (j % 2 == 0) {
                                    j++;
                                    node2.getTextContent();
                                    continue;
                                }
                                if (j % 2 == 1) {
                                    if (j % 38 == 1) {
                                        pItem.setParkFacility1(node2.getTextContent());
                                    }
                                    if (j % 38 == 3) {
                                        pItem.setParkFacility2(node2.getTextContent());
                                    }
                                    if (j % 38 == 5) {
                                        pItem.setParkType(node2.getTextContent());
                                    }
                                    if (j % 38 == 7) {
                                        pItem.setPhone2(node2.getTextContent());
                                    }
                                    if (j % 38 == 9) {
                                        pItem.setParkFacility3(node2.getTextContent());
                                    }
                                    if (j % 38 == 11) {
                                        pItem.setLongitude(node2.getTextContent());
                                    }
                                    if (j % 38 == 13) {
                                        pItem.setName(node2.getTextContent());
                                    }
                                    if (j % 38 == 15) {
                                        pItem.setParkFacility4(node2.getTextContent());
                                    }
                                    if (j % 38 == 17) {
                                        pItem.setParkExtent(node2.getTextContent());
                                    }
                                    if (j % 38 == 19) {
                                        pItem.setAddress(node2.getTextContent());
                                    }
                                    if (j % 38 == 21) {
                                        pItem.setLatitude(node2.getTextContent());
                                    }
                                    if (j % 38 == 23) {
                                        pItem.setSuportName(node2.getTextContent());
                                    }
                                    if (j % 38 == 25) {
                                        pItem.setAddr(node2.getTextContent());
                                    }
                                    if (j % 38 == 27) {
                                        pItem.setParkFacility5(node2.getTextContent());
                                    }
                                    if (j % 38 == 29) {
                                        pItem.setManageNum(node2.getTextContent());
                                    }
                                    if (j % 38 == 31) {
                                        pItem.setDateMade(node2.getTextContent());
                                    }
                                    if (j % 38 == 35) {
                                        pItem.setPhone(node2.getTextContent());
                                    }
                                    if (j % 38 == 37) {
                                        pItem.setDate(node2.getTextContent());
                                    }
                                    j++;
                                }
                            }
                            if (node2.getNodeName().equals("null")) {
                                if (j % 2 == 1) {
                                    System.out.println(node2.getTextContent());
                                    if (j % 38 == 1) {
                                        pItem.setParkFacility1(node2.getTextContent());
                                    }
                                    if (j % 38 == 3) {
                                        pItem.setParkFacility2(node2.getTextContent());
                                    }
                                    if (j % 38 == 5) {
                                        pItem.setParkType(node2.getTextContent());
                                    }
                                    if (j % 38 == 7) {
                                        pItem.setPhone2(node2.getTextContent());
                                    }
                                    if (j % 38 == 9) {
                                        pItem.setParkFacility3(node2.getTextContent());
                                    }
                                    if (j % 38 == 11) {
                                        pItem.setLongitude(node2.getTextContent());
                                    }
                                    if (j % 38 == 13) {
                                        pItem.setName(node2.getTextContent());
                                    }
                                    if (j % 38 == 15) {
                                        pItem.setParkFacility4(node2.getTextContent());
                                    }
                                    if (j % 38 == 17) {
                                        pItem.setParkExtent(node2.getTextContent());
                                    }
                                    if (j % 38 == 19) {
                                        pItem.setAddress(node2.getTextContent());
                                    }
                                    if (j % 38 == 21) {
                                        pItem.setLatitude(node2.getTextContent());
                                    }
                                    if (j % 38 == 23) {
                                        pItem.setSuportName(node2.getTextContent());
                                    }
                                    if (j % 38 == 25) {
                                        pItem.setAddr(node2.getTextContent());
                                    }
                                    if (j % 38 == 27) {
                                        pItem.setParkFacility5(node2.getTextContent());
                                    }
                                    if (j % 38 == 29) {
                                        pItem.setManageNum(node2.getTextContent());
                                    }
                                    if (j % 38 == 31) {
                                        pItem.setDateMade(node2.getTextContent());
                                    }
                                    if (j % 38 == 33) {
                                        pItem.setId(node2.getTextContent());
                                    }
                                    if (j % 38 == 35) {
                                        pItem.setPhone(node2.getTextContent());
                                    }
                                    if (j % 38 == 37) {
                                        pItem.setDate(node2.getTextContent());
                                    }
                                }
                                j++;
                            }
                            if (node2.getNodeName().equals("double")) {
                                if (j % 2 == 1) {
                                    if (j % 38 == 33) {
                                        pItem.setId(node2.getTextContent());
                                    }
                                }
                                j++;
                            }
                        }
                    }
                }
                if (connection.DBInsert_park(pItem) == false) {
                    break;
                }
            }
        }

    }
    
    static void Hospital() throws ParserConfigurationException, SAXException, IOException {
        DBConnect_parsing connection = new DBConnect_parsing();
        Item_hospital pItem = new Item_hospital();

        DocumentBuilderFactory factory;
        DocumentBuilder builder;
        Document doc;
        int nNumOfRows = 14538;
        int nPageNo = 1;
        String strServiceKey_ = "1K4xNbu%2FFeXw9unO7O8Buk%2BLKkHhNI%2F0uPzNY5NjUEdvQBFoqXOibJ2uz%2BYO3wZKJENXQXh7qi2Ligdjx5c0KA%3D%3D";

        String strUrl = "http://apis.data.go.kr/B551182/hospInfoService/getHospBasisList";
        String strServiceKey = "?serviceKey=" + strServiceKey_;

        //String strNumOfRows = "?numOfRows="+nNumOfRows;
        String strA = "&startPage=1&numOfRows=" + nNumOfRows + "&dgsbjtCd=11";

        String pageNo = "&pageNo=" + nPageNo;
        String strMyURL = strUrl + strServiceKey + pageNo + strA;

        System.out.println(strMyURL);

        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        doc = builder.parse(strMyURL);

        NodeList list = doc.getElementsByTagName("Item");
        for (int i = 0; i < list.getLength(); i++) {
            for (Node node = list.item(i).getFirstChild(); node != null; node = node.getNextSibling()) {
                switch (node.getNodeName()) {
                    case "addr":
                        pItem.setAddr(node.getTextContent());
                        break;
                    case "clCdNm":
                        pItem.setClCdNm(node.getTextContent());
                        break;
                    case "drTotCnt":
                        pItem.setDrTotCnt(node.getTextContent());
                        break;
                    case "sgguCdNm":
                        pItem.setSgguCdNm(node.getTextContent());
                        break;
                    case "sidoCdNm":
                        pItem.setSidoCdNm(node.getTextContent());
                        break;
                    case "telno":
                        pItem.setTelno(node.getTextContent());
                        break;
                    case "XPos":
                        pItem.setXPos(node.getTextContent());
                        break;
                    case "YPos":
                        pItem.setYPos(node.getTextContent());
                        break;
                    case "yadmNm":
                        pItem.setYadmNm(node.getTextContent());
                        break;
                    default:
                        break;
                }
            }
            System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
            
            if (connection.DBInsert_hospital(pItem) == false) {
                break;
            }
        }
    }
}
