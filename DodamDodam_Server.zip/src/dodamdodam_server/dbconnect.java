/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam_server;

/**
 *
 * @author 915-22
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class dbconnect {
    private Connection conn;
    private static final String USERNAME = "root";
    private static final String PASSWORD = "123123";
    private static final String URL = "jdbc:mysql://localhost/ourdb";
 
    public dbconnect() {
        // connection객체를 생성해서 디비에 연결해줌..
        try {
            Class.forName("com.mysql.jdbc.Driver");
 
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
 
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.println("클래스 적재 실패");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.println("연결 실패");
        }
    }
 
    public void insertdb(dbset dbset) { //데이터베이스에 정보를 삽입 - 회원가입 구현부
        String sql = "insert into ourdb values(?,?,?,?);";
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, dbset.getNum());
            pstmt.setString(2, dbset.getId());
            pstmt.setString(3, dbset.getPassword());
            pstmt.setString(4, dbset.getEmail());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null && !pstmt.isClosed())
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
 
    public void updatedb(dbset dbset) {
        String sql = "update ourdb set id=?, password=?, email=? where num = ?;";
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dbset.getId());
            pstmt.setString(2, dbset.getPassword());
            pstmt.setString(3, dbset.getEmail());
            pstmt.setInt(4, dbset.getNum());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null && !pstmt.isClosed())
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
 
    public void deletedb(int num) {
        String sql = "delete from ourdb where num = ?;";
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null && !pstmt.isClosed())
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
 
    public dbset selectOne(int num) {   //데이터베이스에서 하나의 객체를 선택
        String sql = "select * from ourdb where num = ?;";
        PreparedStatement pstmt = null;
        dbset re = new dbset();
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, num);
            ResultSet rs = pstmt.executeQuery();
 
            if (rs.next()) {
                re.setNum(rs.getInt("num"));
                re.setId(rs.getString("id"));
                re.setPassword(rs.getString("password"));
                re.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null && !pstmt.isClosed())
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return re;
    }
 
    public List<dbset> selectAll() {    //데이터베이스에 저장된 객체들을 모두 불러옴
        String sql = "select * from ourdb;";
        PreparedStatement pstmt = null;
 
        List<dbset> list = new ArrayList<dbset>();  //ArrayList에 불러온 객체들을 저장
 
        try {
            pstmt = conn.prepareStatement(sql);
            ResultSet re = pstmt.executeQuery();
 
            while (re.next()) {
                dbset s = new dbset();
                s.setNum(re.getInt("num"));
                s.setId(re.getString("id"));
                s.setPassword(re.getString("password"));
                s.setEmail(re.getString("email"));
                list.add(s);
            }
 
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null && !pstmt.isClosed())
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return list;
    }
}
