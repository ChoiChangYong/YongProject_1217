/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam_server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author user
 */
public class JSON_parsing_EX {

    private static String readAll(Reader rd) throws IOException
    {
        StringBuilder sb = new StringBuilder();
        int cp;
        while((cp = rd.read()) != -1)
        {
            sb.append((char) cp);
        }
        return sb.toString();
    }
    
    public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException
    {
        InputStream is = new URL(url).openStream();
        try
        {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
        }
        finally
        {
            is.close();
        }
    }
    public void frequentzone() throws IOException, JSONException
    {
        DBConnect_parsing connection = new DBConnect_parsing();
        Item_frequentzone pItem = new Item_frequentzone();
        
        int totalCount_all = 0;

        String Url = "http://apis.data.go.kr/B552061/frequentzoneChild/getRestFrequentzoneChild?ServiceKey=1K4xNbu%2FFeXw9unO7O8Buk%2BLKkHhNI%2F0uPzNY5NjUEdvQBFoqXOibJ2uz%2BYO3wZKJENXQXh7qi2Ligdjx5c0KA%3D%3D";
        int Year[] = new int[5];
        Year[0] = 2017027;
        Year[1] = 2016044;
        Year[2] = 2015049;
        Year[3] = 2014110;
        Year[4] = 2013097;
        //2017027 2016044 2015049 2014110 2013097
        String str_Year = "";
        int siDo = 0;
        String str_siDo = "";
        JSONObject json;
        JSONObject page;
        JSONArray arr;

        String totalCount = "";
        String resultCode = "";

        for (int k = 0; k < 5; k++) {
            str_Year = "&searchYearCd=" + Year[k];
            System.out.println("=============== Year = " + Year[k] + " ===============");
            siDo = 11;
            str_siDo = "&siDo=" + siDo;

            json = readJsonFromUrl(Url + str_Year + str_siDo);
            System.out.println(json.toString());
            //System.out.println(Url+strA);

            page = json.getJSONObject("searchResult");

            arr = page.getJSONArray("frequentzone");

            for (int j = 0; j < arr.length(); j++) {
                pItem.setId(arr.getJSONObject(j).getString("fid"));
                pItem.setGrp_id(arr.getJSONObject(j).getString("grp_id"));
                pItem.setName(arr.getJSONObject(j).getString("spotname"));
                pItem.setOccrrnc_co(arr.getJSONObject(j).getString("occrrnc_co"));
                pItem.setDthinj_co(arr.getJSONObject(j).getString("dthinj_co"));
                pItem.setDeath_co(arr.getJSONObject(j).getString("death_co"));
                pItem.setXPos(arr.getJSONObject(j).getString("x_crd"));
                pItem.setYPos(arr.getJSONObject(j).getString("y_crd"));

                connection.DBInsert_frequentzone(pItem);
            }
            totalCount = json.getString("totalCount");
            totalCount_all += Integer.parseInt(totalCount);
            resultCode = json.getString("resultCode");
            System.out.println("totalCount = " + totalCount);
            System.out.println("resultCodet = " + resultCode);
            System.out.println("siDo = " + siDo);
            for (int i = 26; i <= 50; i++) {
                siDo = i;

                if (!(i > 31 && i < 36) && i != 49) {
                    str_siDo = "&siDo=" + siDo;

                    json = readJsonFromUrl(Url + str_Year + str_siDo);
                    System.out.println(json.toString());
                    //System.out.println(Url+strA);

                    page = json.getJSONObject("searchResult");

                    arr = page.getJSONArray("frequentzone");

                    for (int j = 0; j < arr.length(); j++) {
                        pItem.setId(arr.getJSONObject(j).getString("fid"));
                        pItem.setGrp_id(arr.getJSONObject(j).getString("grp_id"));
                        pItem.setName(arr.getJSONObject(j).getString("spotname"));
                        pItem.setOccrrnc_co(arr.getJSONObject(j).getString("occrrnc_co"));
                        pItem.setDthinj_co(arr.getJSONObject(j).getString("dthinj_co"));
                        pItem.setDeath_co(arr.getJSONObject(j).getString("death_co"));
                        pItem.setXPos(arr.getJSONObject(j).getString("x_crd"));
                        pItem.setYPos(arr.getJSONObject(j).getString("y_crd"));

                        connection.DBInsert_frequentzone(pItem);
                    }
                    totalCount = json.getString("totalCount");
                    totalCount_all += Integer.parseInt(totalCount);
                    resultCode = json.getString("resultCode");
                    System.out.println("totalCount = " + totalCount);
                    System.out.println("resultCodet = " + resultCode);
                    System.out.println("siDo = " + siDo);
                }
            }
            System.out.println("totalCount_all = " + totalCount_all);
        }
    }

    public void schoolzone() throws IOException, JSONException {
        DBConnect_parsing connection = new DBConnect_parsing();
        Item_schoolzone pItem = new Item_schoolzone();

        int totalCount_all = 0;

        String Url = "http://apis.data.go.kr/B552061/schoolzoneChild/getRestSchoolzoneChild?ServiceKey=1K4xNbu%2FFeXw9unO7O8Buk%2BLKkHhNI%2F0uPzNY5NjUEdvQBFoqXOibJ2uz%2BYO3wZKJENXQXh7qi2Ligdjx5c0KA%3D%3D";
        int Year[] = new int[5];
        Year[0] = 2017026;
        Year[1] = 2016040;
        Year[2] = 2015042;
        Year[3] = 2014095;
        Year[4] = 2013060;
        //2017027 2016044 2015049 2014110 2013097
        String str_Year = "";
        int siDo = 0;
        String str_siDo = "";
        JSONObject json;
        JSONObject page;
        JSONArray arr;

        String totalCount = "";
        String resultCode = "";

        for (int k = 0; k < 5; k++) {
            str_Year = "&searchYearCd=" + Year[k];
            System.out.println("=============== Year = " + Year[k] + " ===============");
            siDo = 11;
            str_siDo = "&siDo=" + siDo;

            json = readJsonFromUrl(Url + str_Year + str_siDo);
            System.out.println(json.toString());
            //System.out.println(Url+strA);

            page = json.getJSONObject("searchResult");

            arr = page.getJSONArray("frequentzone");

            for (int j = 0; j < arr.length(); j++) {
                pItem.setId(arr.getJSONObject(j).getString("fid"));
                pItem.setGrp_id(arr.getJSONObject(j).getString("grp_id"));
                pItem.setName(arr.getJSONObject(j).getString("spotname"));
                pItem.setOccrrnc_co(arr.getJSONObject(j).getString("occrrnc_co"));
                pItem.setDthinj_co(arr.getJSONObject(j).getString("dthinj_co"));
                pItem.setDeath_co(arr.getJSONObject(j).getString("death_co"));
                pItem.setXPos(arr.getJSONObject(j).getString("x_crd"));
                pItem.setYPos(arr.getJSONObject(j).getString("y_crd"));

                connection.DBInsert_schoolzone(pItem);
            }
            totalCount = json.getString("totalCount");
            totalCount_all += Integer.parseInt(totalCount);
            resultCode = json.getString("resultCode");
            System.out.println("totalCount = " + totalCount);
            System.out.println("resultCodet = " + resultCode);
            System.out.println("siDo = " + siDo);
            for (int i = 26; i <= 50; i++) {
                siDo = i;

                if (!(i > 31 && i < 36) && i != 49) {
                    str_siDo = "&siDo=" + siDo;

                    json = readJsonFromUrl(Url + str_Year + str_siDo);
                    System.out.println(json.toString());
                    //System.out.println(Url+strA);

                    page = json.getJSONObject("searchResult");

                    arr = page.getJSONArray("frequentzone");

                    for (int j = 0; j < arr.length(); j++) {
                        pItem.setId(arr.getJSONObject(j).getString("fid"));
                        pItem.setGrp_id(arr.getJSONObject(j).getString("grp_id"));
                        pItem.setName(arr.getJSONObject(j).getString("spotname"));
                        pItem.setOccrrnc_co(arr.getJSONObject(j).getString("occrrnc_co"));
                        pItem.setDthinj_co(arr.getJSONObject(j).getString("dthinj_co"));
                        pItem.setDeath_co(arr.getJSONObject(j).getString("death_co"));
                        pItem.setXPos(arr.getJSONObject(j).getString("x_crd"));
                        pItem.setYPos(arr.getJSONObject(j).getString("y_crd"));

                        connection.DBInsert_schoolzone(pItem);
                    }
                    totalCount = json.getString("totalCount");
                    totalCount_all += Integer.parseInt(totalCount);
                    resultCode = json.getString("resultCode");
                    System.out.println("totalCount = " + totalCount);
                    System.out.println("resultCodet = " + resultCode);
                    System.out.println("siDo = " + siDo);
                }
            }
            System.out.println("totalCount_all = " + totalCount_all);
        }
    }
}
