/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam_server;

/**
 *
 * @author dodamdodam Team
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class ServerSock {
    public void ServerRun() throws IOException{
        
        ServerSocket server = null;
        int port = 4200;
        Socket socket = null;
        
        InputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        
        try{
            server = new ServerSocket(port);
            while(true){
                System.out.println("-------접속 대기중------");
                socket = server.accept();         // 클라이언트가 접속하면 통신할 수 있는 소켓 반환
                System.out.println(socket.getInetAddress() + "로 부터 연결요청이 들어옴");
                
                is = socket.getInputStream();
                isr = new InputStreamReader(is);
                br = new BufferedReader(isr);
                // 클라이언트로부터 데이터를 받기 위한 InputStream 선언
                
                String recv=null;
                recv=br.readLine();      //클라이언트로부터 데이터를 받음
                strcmpare(recv,socket);
                
                

                
               
                
                break;
                
                
            }
        }catch (Exception e) {
                e.printStackTrace();
            }
        finally{
        try{
                    br.close();
                    isr.close();
                    is.close();
                    server.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
        }
        }
    
    
    public void sendData(String data, Socket socket){
        OutputStream os = null;
        OutputStreamWriter osw = null;
        BufferedWriter bw = null;
        
        try{
            os = socket.getOutputStream();
            osw = new OutputStreamWriter(os);
            bw = new BufferedWriter(osw);
            // 클라이언트로부터 데이터를 보내기 위해 OutputStream 선언
            
            bw.write(data);            // 클라이언트로 데이터 전송
            bw.flush();
        }catch(Exception e1){
            e1.printStackTrace();
        }finally {
            try{
                bw.close();
                osw.close();
                os.close();
                socket.close();
            }catch(Exception e1){
                e1.printStackTrace();
            }
        }
    }    


public void strcmpare(String recv, Socket socket){  //DB와 입력받은 정보를 비교,삽입
                int loginchk;
                loginchk = 0;
                dbconnect temp = new dbconnect();   //데이터베이스 연결 클래스 선언
                
                //# 의 인덱스를 찾는다.
                int idx2 = recv.indexOf("#");
                if(idx2 == -1){ //#이 없음 => 가입이 아니라 로그인
                    //^ 의 인덱스를 찾는다
                int idx = recv.indexOf("^"); 
                
                // ^ 앞부분을 추출
                // substring은 첫번째 지정한 인덱스는 포함하지 않는다.
                String ID = recv.substring(0, idx);

                // 뒷부분을 추출
                // 아래 substring은 ^ 바로 뒷부분인 n부터 추출된다.
                String Password = recv.substring(idx+1);

                System.out.print("클라이언트 => 로그인 - ID:" + ID + " PASSWORD:" + Password);
                List<dbset> list = new ArrayList<dbset>();  //데이터베이스를 저장할 ArrayList 선언
                list = temp.selectAll();    //ArrayList에 데이터베이스의 모든 파일을 저장
                for(int i = 0; i<list.size() ;i++){  //불러온 데이터베이스와 입력받은 값을 데이터베이스 갯수만큼 비교
                    if(list.get(i).getId().equals(ID)){ //입력받은 ID와 데이터베이스의 ID가 같고
                        if(list.get(i).getPassword().equals(Password)){ //PASSWORD가 같으면
                            sendData("O",socket);    //로그인 성공을 뜻하는 문자열을 클라이언트로 전송
                            System.out.println("  --- 로그인 성공");
                            loginchk = 1;   //로그인 성공 유무를 위한 변수
                        }
                    }
                }
                
                if(loginchk != 1){
                    System.out.println("  --- 로그인 실패");
                }
                
            }
                else if(idx2 > 0){  //회원가입
                    int chk;  //아이디 중복체크를 위한 변수
                    chk = 0;  //아이디 중복체크가 끝나고 다음 중복체크를 위한 초기화
                        //^ 의 인덱스를 찾는다
                    int idx1 = recv.indexOf("^"); 

                    // ^ 앞부분을 추출
                    // substring은 첫번째 지정한 인덱스는 포함하지 않는다.
                    String ID = recv.substring(0, idx1);
                    String Password = recv.substring(idx1+1,idx2);

                    // 뒷부분을 추출
                    // 아래 substring은 # 바로 뒷부분인 n부터 추출된다.
                    String Email = recv.substring(idx2+1);

                    System.out.print("클라이언트 => 회원가입 - ID:" + ID + " PASSWORD:" + Password + " E-MAIL:" + Email);
                    
                    List<dbset> list2 = new ArrayList<dbset>();
                    list2 = temp.selectAll();
                    for(int j = 0; j<list2.size() ;j++){  //불러온 데이터베이스와 입력받은 값을 50개까지 비교
                        if(list2.get(j).getId().equals(ID)){
                                sendData("E",socket);    //이미 아이디가 있다는 중복메세지를 보내줌
                                System.out.println("  --- 회원가입 실패");
                                chk = 1;

                        }
                    }

                    if(chk == 0){ //아이디가 중복되지 않았을 때
                        dbset newinsert = new dbset(1,ID,Password,Email);   //받은 정보를 dbset 객체로 선언
                        temp.insertdb(newinsert);   //객체를 데이터베이스에 삽입
                        System.out.println("  --- 회원가입 성공");
                        sendData("회원가입완료",socket);
                    }
                }
                
}
}