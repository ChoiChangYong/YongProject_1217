/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

/**
 *
 * @author dodamdodam Team
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ClientSock {
     public int ClientRun(int type, String ID,String Password,String Email){
        int pass;
        pass = 0;
         
        Socket socket = null;
        OutputStream os = null;
        OutputStreamWriter osw =null;
        BufferedWriter bw = null;
        
        InputStream is =null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        
        try{
            socket = new Socket("127.0.0.1", 4200);
            os = socket.getOutputStream();
            osw = new OutputStreamWriter(os);
            bw = new BufferedWriter(osw);            //서버로 전송을 위한 OutputStream
        
            is = socket.getInputStream();
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);        // 서버로부터 Data를 받음
            
            if(type == 1){  //로그인부분
            String sendclient;
            sendclient = ID + "^" + Password;  //하나의 문자열을 보내기 위해
            
            bw.write(sendclient);   //문자열을 버퍼에 작성하여 전송
            bw.newLine();
            bw.flush();
            
            String receiveData = "";
            receiveData = br.readLine();        // 서버로부터 데이터 한줄 읽음
            
            if(receiveData.equals("O")){
                pass = 1;
                return pass;
            }
            
            }
            
            ///////////////////////////////////////////////////////////////
            
            if(type == 2){  //회원가입부분
                String DBInsert;
                DBInsert = ID + "^" + Password + "#" + Email;
                int nopass;
                nopass = 0;
                
                
                bw.write(DBInsert);
                bw.newLine();
                bw.flush();
            
                String receiveData = "";
                receiveData = br.readLine();        // 서버로부터 데이터 한줄 읽음

                System.out.println("서버로부터 받은 데이터 : " + receiveData);
                if(receiveData.equals("E")){
                    nopass = 2;
                    return nopass;
                }
                pass = 0;
                }
            
            
            
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            try{
                bw.close();
                osw.close();
                os.close();
                br.close();
                isr.close();
                is.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }    
        return pass;
     }
}
