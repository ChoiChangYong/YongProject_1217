/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class IP_NOKController implements Initializable {
    //ID와 PASSWORD를 확인해주세요.
    @FXML
    private JFXButton btn_IP_NOK;
    @FXML
    private AnchorPane pn_IP_NOK;
    
    @FXML
    private void IP_NOKACTION(ActionEvent event) throws IOException, Exception {
        pn_IP_NOK.getScene().getWindow().hide();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
