/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class HOME2Controller implements Initializable {
    private double xOffset = 0;
    private double yOffset = 0;
    
    @FXML
    private JFXButton btn_도담도담소개, btn_도담도담검색, btn_도담도담측정, btn_측정시작, btn_종료2, btn_검색시작;
    @FXML
    private AnchorPane pn_도담도담소개, pn_도담도담검색,pn_도담도담측정, pn_종료2, pn_newHOME2;
    @FXML
    private WebView myS_WV, myC_WV;
    
    //창전환
    @FXML
    private void handleButtonAction2(ActionEvent event){
        if(event.getSource() == btn_도담도담소개){
                pn_도담도담소개.toFront();
        }
        else
            if(event.getSource() == btn_도담도담검색){
                pn_도담도담검색.toFront();
            }
        else
            if(event.getSource() == btn_도담도담측정){
                pn_도담도담측정.toFront();
    }
    }
    
    //종료
    @FXML
    private void handleClose2(MouseEvent event) {
        System.exit(0);
    }
    
    //검색웹뷰
    @FXML
    private void SerchWV(ActionEvent event) throws IOException{
        
        //pn_newHOME2.setDisable(true);
        
        Parent Menu = FXMLLoader.load(getClass().getResource("Menu.fxml"));
        Stage stage = new Stage();
        stage.initStyle(StageStyle.TRANSPARENT);
        Menu.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event){
                xOffset = event.getSceneX();
                yOffset = event.getSceneY();
            }
        });
          Menu.setOnMouseDragged(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event){
                stage.setX(event.getScreenX() - xOffset);
                stage.setY(event.getScreenY() - yOffset);
            }
        });
        
        Stage tar = new Stage();
        myS_WV = new WebView();
        WebEngine engine = myS_WV.getEngine();        
        engine.load("http://localhost:80/DodamDodam.php");
        Scene s = new Scene(myS_WV, 1300, 800);
        tar.setScene(s);
        tar.show();
      
        Scene MenuR = new Scene(Menu);
        stage.setScene(MenuR);  
        stage.show();
    }
    
    //측정웹뷰
    @FXML
    private void CCWV(ActionEvent event) throws IOException{
               
        //pn_newHOME2.setDisable(true);
        
        Parent Menu2 = FXMLLoader.load(getClass().getResource("Menu2.fxml"));
        Stage stage = new Stage();
        stage.initStyle(StageStyle.TRANSPARENT);
        
        
        Menu2.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event){
                xOffset = event.getSceneX();
                yOffset = event.getSceneY();
            }
        });
          Menu2.setOnMouseDragged(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event){
                stage.setX(event.getScreenX() - xOffset);
                stage.setY(event.getScreenY() - yOffset);
            }
        });
        
        Stage Star = new Stage();
        myC_WV = new WebView();
        WebEngine engine = myC_WV.getEngine();        
        engine.load("http://localhost:80/DodamDodam_2.php");
        Scene ss = new Scene(myC_WV, 1300, 800);
        Star.setScene(ss);
        Star.show();
    
        Scene MenuRR = new Scene(Menu2);
        stage.setScene(MenuRR);  
        stage.show();
    }
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
