/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author admin
 */
public class Login_OKController implements Initializable {
    private double xOffset = 0;
    private double yOffset = 0;
    
    @FXML
    private JFXButton btn_SignOK;
    
    @FXML
    private AnchorPane pn_LoginOK;

    @FXML
    private void LoginOK(ActionEvent event) throws IOException, Exception {
        pn_LoginOK.getScene().getWindow().hide();
        
    
        Parent HOME2Parent = FXMLLoader.load(getClass().getResource("HOME2.fxml"));
        
        Stage stage = new Stage();
        stage.initStyle(StageStyle.TRANSPARENT);    
        
          HOME2Parent.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event){
                xOffset = event.getSceneX();
                yOffset = event.getSceneY();
            }
        });
          
        HOME2Parent.setOnMouseDragged(new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent event){
                stage.setX(event.getScreenX() - xOffset);
                stage.setY(event.getScreenY() - yOffset);
            }
        });
       
        Scene HOME2Scene = new Scene(HOME2Parent);
        HOME2Parent.setStyle("-fx-background-color: rgba(0,0,0,0);");
        HOME2Scene.setFill(Color.TRANSPARENT);
        
        stage.setScene(HOME2Scene);
        stage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
