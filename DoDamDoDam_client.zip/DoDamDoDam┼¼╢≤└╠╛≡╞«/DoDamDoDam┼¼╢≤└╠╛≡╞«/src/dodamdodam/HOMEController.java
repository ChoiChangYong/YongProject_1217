/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dodamdodam;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.validation.RequiredFieldValidator;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.*;
import javafx.stage.StageStyle;



/**
 *
 * @author admin
 */
public class HOMEController implements Initializable {
    private double xOffset = 0;
    private double yOffset = 0;
    
    @FXML
    private JFXButton btn_회원가입, btn_로그인, btn_종료2;
    
    @FXML
    private AnchorPane pn_회원가입, pn_로그인,pn_newHOME2, pn_rootPane;
    
    @FXML
    private JFXButton btn_로그인OK, btn_회원가입OK;
    
    @FXML
    private JFXTextField text_회원가입_E, text_회원가입_ID, text_회원가입_PASSWORD;
    
    @FXML
    private JFXTextField text_login_ID, text_login_PASSWORD;
    
    //창전환
    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource() == btn_회원가입){
            pn_회원가입.toFront();
        }
        else
            if(event.getSource() == btn_로그인){
                pn_로그인.toFront();
            }
    }
    
    //종료
    @FXML
    private void handleClose(MouseEvent event) {
        System.exit(0);
    }
    
    //회원가입화면 OK
     @FXML
    private void Signup_ACTION(ActionEvent event) throws IOException {
        String NEW_ID = "";
        String NEW_PASSWORD = "";
        String EMAIL = "";
        NEW_ID = text_회원가입_ID.getText();
        NEW_PASSWORD  = text_회원가입_PASSWORD.getText();
        EMAIL = text_회원가입_E.getText();
        if(NEW_ID.equals("") || NEW_PASSWORD.equals("") || EMAIL.equals("")){
           Parent SpaceUP = FXMLLoader.load(getClass().getResource("Space_Signup.fxml"));
           Stage stage = new Stage();
           stage.initStyle(StageStyle.TRANSPARENT);
           Scene Spacesignup = new Scene(SpaceUP);
           stage.setScene(Spacesignup);
           stage.show();
        }
        else{
            ClientSock clie = new ClientSock();
            int check = clie.ClientRun(2,NEW_ID,NEW_PASSWORD,EMAIL);

            if(check == 2){ //아이디가 중복될 때
                Parent overlap = FXMLLoader.load(getClass().getResource("Overlap_IP.fxml"));
                Stage over = new Stage();
                over.initStyle(StageStyle.TRANSPARENT);
                Scene doninsert = new Scene(overlap);
                over.setScene(doninsert);
                over.show();
            }
            else{   //아이디가 중복되지 않을 때 == 회원가입이 성공했을 때
            Parent Signup_OK = FXMLLoader.load(getClass().getResource("Signup_OK.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            Scene Signup = new Scene(Signup_OK);
            stage.setScene(Signup);
            stage.show();
            pn_로그인.toFront();
            }
        }
    }
    
    //로그인화면 OK
    @FXML
    private void SecondHOME(MouseEvent event) throws IOException, SQLException { 
        String ID;  //클라이언트 GUI의 텍스트를 저장할 변수들
        String PASSWORD;
        int pass = 0;   //로그인 성공 실패를 확인하기 위한 변수
        
        ClientSock clie = new ClientSock(); //클라이언트 통신 객체 선언
        ID = text_login_ID.getText();   //클라이언트의 텍스트들을 받아와 저장
        PASSWORD = text_login_PASSWORD.getText();
        pass = clie.ClientRun(1,ID,PASSWORD,"x");   //1은 로그인 타입임을 알림


        if(pass == 1){  //아이디와 비밀번호가 일치한다면
            pn_rootPane.getScene().getWindow().hide();

            Parent Signup_OK = FXMLLoader.load(getClass().getResource("Login_OK.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            Scene Signup = new Scene(Signup_OK);
            stage.setScene(Signup);
            stage.show();
        }
        
        //ID와 PASSWORD를 확인해주세요. 화면을 출력
        else{
            Parent IP_Nok = FXMLLoader.load(getClass().getResource("IP_NOK.fxml"));
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            Scene ipnok = new Scene(IP_Nok);
            stage.setScene(ipnok);
            stage.show();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}






